<?php
include_once('./config.php');
if (isset($_REQUEST['id'])) {
    $selectData = "SELECT *, CONCAT(start_date,' to ', end_date) as Date FROM event_list WHERE id=".$_REQUEST['id']."";
    $stmt = $conn->prepare($selectData);
    $stmt->execute();
    $eventresult = $stmt->fetchAll();           
    $from_date = new DateTime($eventresult[0]['start_date']);    
    $to_date = new DateTime($eventresult[0]['end_date']);    
    $Dayname = array();
    for ($date = $from_date; $date <= $to_date; $date->modify('+1 day')) {
        $Dayname[$date->format('m/d/Y')] =  $date->format('l');        
    }    
    $previewHtml = '';
    if (isset($Dayname) && count($Dayname) > 0) {        
        $previewHtml .= '<div class="container">
            <h2>Event View Page</h2>
            <table class="table">
            <thead>
                <tr>                    
                    <th>Date</th>
                    <th>Day Name</th>                   
                </tr>
            </thead>
            <tbody>';                
            if (isset($Dayname) && !empty($Dayname)) {                    
                // output data of each row
                foreach($Dayname as $key=>$Data) {                                                         
                    $previewHtml .= '<tr><td>'.$key.'</td><td>'.$Data.'</td></tr>';                                        
                }            
              }                            
            $previewHtml .= '</tbody>
        </table>
        </div>';        
    }
    echo $previewHtml;die;
}
if (isset($_REQUEST) && !empty($_REQUEST) && !isset($_REQUEST['id'])) {
    $title = isset($_REQUEST['title']) ? $_REQUEST['title'] : '';
    $start_date = isset($_REQUEST['startdate']) ? date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $_REQUEST['startdate']))) : '';    
    $end_date = isset($_REQUEST['enddate']) ? date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $_REQUEST['enddate']))) : '';
    $Repeat = isset($_REQUEST['Repeat']) ? $_REQUEST['Repeat'] : '';    
    $lstRepeatType = isset($_REQUEST['lstRepeatType']) && $Repeat == 0 ? $_REQUEST['lstRepeatType'] : '';    
    $lstEvery = isset($_REQUEST['lstEvery']) && $Repeat == 0 ? $_REQUEST['lstEvery'] : '';    
    $lstRepeatOn = isset($_REQUEST['lstRepeatOn']) && $Repeat == 1 ? $_REQUEST['lstRepeatOn'] : '';    
    $lstRepeatWeek = isset($_REQUEST['lstRepeatWeek']) && $Repeat == 1 ? $_REQUEST['lstRepeatWeek'] : '';    
    $lstRepeatMonth = isset($_REQUEST['lstRepeatMonth']) && $Repeat == 1 ? $_REQUEST['lstRepeatMonth'] : '';    
    $sql = "INSERT INTO event_list (title, `start_date`, `end_date`,Recurrence,lstRepeatType,lstEvery,lstRepeatOn,lstRepeatWeek,lstRepeatMonth)
    VALUES ('$title', '$start_date','$end_date', '$Repeat','$lstRepeatType','$lstEvery', '$lstRepeatOn','$lstRepeatWeek', '$lstRepeatMonth')";
    // use exec() because no results are returned
    $conn->exec($sql);
    // $sql->execute();
    // $sql->fetch();
    echo true;
}
$selectData = "SELECT *, CONCAT(start_date,' to ', end_date) as Date FROM event_list";
$stmt = $conn->prepare($selectData);
$stmt->execute();
$result = $stmt->fetchAll();
?>
<html>
<head>
    <title>Event Management</title>
    <!-- Latest compiled and minified CSS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.js" integrity="sha256-DrT5NfxfbHvMHux31Lkhxg42LY6of8TaYyK50jnxRnM=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-notify/0.2.0/css/bootstrap-notify.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker3.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.79/jquery.form-validator.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-notify/0.2.0/js/bootstrap-notify.min.js"></script> 
    <link href="https://code.jquery.com/ui/jquery-ui-git.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/ui/jquery-ui-git.js"></script>
    <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
<style>
.error {
    color: red;
}
</style>
</head>
<body>
<div class="maindiv">
    <div class="container">
        <h2>Add Event Page</h2>
        <form name="InsertEvent" id="InsertEvent" autocomplete="off">
            <div class="row">
                <div class="col-md-1">Event Title</div>
                <div class="col-md-4"><input type="text" name="title" class="input-sm"></div>
            </div>
            <div class="row">
                <div class="col-md-1">Start Date</div>
                <div class="col-md-4"><input type="text" name="startdate" id="StartDate" class="input-sm startdate"></div>
            </div>
            <div class="row">
                <div class="col-md-1">End Date: </div>
                <div class="col-md-4"><input type="text" name="enddate" id="EndDate" class="input-sm enddate"></div>
            </div>
            <div class="row">
                <div class="col-md-1">Recurrence: </div>
                <div class="col-md-4">
                    <input type="radio" name="Repeat" value="0" checked>&nbsp; Repeat
                    <select id="lstRepeatType" class="textbox-medium" name="lstRepeatType" style="font-size: x-small; width: 100px; font-family: Verdana" tabindex="10">
                        <option selected="selected" value="1">Every</option>
                        <option value="2">Every Other</option>
                        <option value="3">Every Third</option>
                        <option value="4">Every Fourth</option>
                    </select>                                
                    <select id="lstEvery" class="textbox-medium" name="lstEvery" style="font-size: x-small;
                        width: 66px; font-family: Verdana" tabindex="10">
                        <option selected="selected" value="1">Day</option>
                        <option value="2">Week</option>
                        <option value="3">Month</option>
                        <option value="4">Year</option>
                    </select>                
            </div>
            </div>
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-4">
                    <input type="radio" name="Repeat" value="1">&nbsp; Repeat on the
                    <select id="lstRepeatOn" class="textbox-middle" name="lstRepeatOn" style="font-size: x-small;
                        width: 68px; font-family: Verdana" tabindex="12">
                        <option selected="selected" value="1">First</option>
                        <option value="2">Second</option>
                        <option value="3">Third</option>
                        <option value="4">Fourth</option>
                    </select>
                    <select id="lstRepeatWeek" class="textbox-middle" name="lstRepeatWeek" style="font-size: x-small; width: 56px; font-family: Verdana" tabindex="13">
                        <option selected="selected" value="0">Sun</option>
                        <option value="1">Mon</option>
                        <option value="2">Tue</option>
                        <option value="3">Wed</option>
                        <option value="4">Thu</option>
                        <option value="5">Fri</option>
                        <option value="6">Sat</option>
                    </select>                             
                    <select id="lstRepeatMonth" class="textbox-middle" language="javascript" name="lstRepeatMonth" style="font-size: x-small; width: 80px;
                            font-family: Verdana" tabindex="14">
                        <option selected="selected" value="1">Month</option>
                        <option value="3">3 Months</option>
                        <option value="4">4 Months</option>
                        <option value="6">6 Months</option>
                        <option value="12">Year</option>
                    </select>             
            </div>
            </div>
            <div class="row">
                <span class="Recurrence"></span>
            </div>
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-2"><button name="submit" class="btn btn-success" id="insertData" value="submit">Submit</button></div>
            </div>
        </form>
    </div>
    <div class="container">
        <h2>Event List Page</h2>
        <table class="table" id="example">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Dates</th>
                    <th>Occurrence</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            if (isset($result) && !empty($result)) {                    
                // output data of each row
                foreach($result as $Data) {                   
                  ?>
                <tr>
                    <td><?php echo $Data['id']; ?></td>
                    <td><?php echo $Data['title']; ?></td>
                    <td><?php echo $Data['Date']; ?></td>
                    <td>
                    <?php 
                    if ($Data['Recurrence'] == 0) {
                        if ($Data['lstRepeatType'] == 1) {
                            $lstRepeatType = 'Every';
                        } else if ($Data['lstRepeatType'] == 2) {
                            $lstRepeatType = 'Every Other';
                        } else if ($Data['lstRepeatType'] == 3) {
                            $lstRepeatType = 'Every Third';
                        } else if ($Data['lstRepeatType'] == 4) {
                            $lstRepeatType = 'Every Forth';
                        } else {
                            $lstRepeatType = '';
                        }
                        if ($Data['lstEvery'] == 1) {
                            $lstEvery = 'Day';
                        } else if ($Data['lstEvery'] == 2) {
                            $lstEvery = 'Week';
                        } else if ($Data['lstEvery'] == 3) {
                            $lstEvery = 'Month';
                        } else if ($Data['lstEvery'] == 4) {
                            $lstEvery = 'Year';
                        } else {
                            $lstEvery = '';
                        }
                        echo $lstRepeatType.' '.$lstEvery;
                    } else if ($Data['Recurrence'] == 1) {
                        if ($Data['lstRepeatOn'] == 1) {
                            $lstRepeatOn = 'First';
                        } else if ($Data['lstRepeatOn'] == 2) {
                            $lstRepeatOn = 'Second';
                        } else if ($Data['lstRepeatOn'] == 3) {
                            $lstRepeatOn = 'Third';
                        } else if ($Data['lstRepeatOn'] == 4) {
                            $lstRepeatOn = 'Forth';
                        } else {
                            $lstRepeatOn = '';
                        }
                        if ($Data['lstRepeatWeek'] == 0) {
                            $lstRepeatWeek = 'Sun';
                        } else if ($Data['lstRepeatWeek'] == 1) {
                            $lstRepeatWeek = 'Mon';
                        } else if ($Data['lstRepeatWeek'] == 2) {
                            $lstRepeatWeek = 'Tue';
                        } else if ($Data['lstRepeatWeek'] == 3) {
                            $lstRepeatWeek = 'Wed';
                        } else if ($Data['lstRepeatWeek'] == 4) {
                            $lstRepeatWeek = 'Thu';
                        }else if ($Data['lstRepeatWeek'] == 5) {
                            $lstRepeatWeek = 'Fri';
                        }else if ($Data['lstRepeatWeek'] == 6) {
                            $lstRepeatWeek = 'Sat';
                        } else {
                            $lstRepeatWeek = '';
                        }
                        if ($Data['lstRepeatMonth'] == 1) {
                            $lstRepeatMonth = 'Month';
                        } else if ($Data['lstRepeatMonth'] == 3) {
                            $lstRepeatMonth = '3 Months';
                        } else if ($Data['lstRepeatMonth'] == 4) {
                            $lstRepeatMonth = '4 Month';
                        } else if ($Data['lstRepeatMonth'] == 6) {
                            $lstRepeatMonth = '6 Month';
                        } else if ($Data['lstRepeatMonth'] == 12) {
                            $lstRepeatMonth = 'Year';
                        } else {
                            $lstRepeatMonth = '';
                        }
                        echo $lstRepeatOn.' '. $lstRepeatWeek.' '.$lstRepeatMonth;
                    }
                    ?>
                    </td>
                    <td>
                    <button id="eventview" view-id="<?php echo $Data['id'];?>" class="btn btn-primary">View</button></a>
                    </td>
                </tr>
                  <?php
                }            
              } else {
                echo "0 results";
              }
            ?>                
            </tbody>
        </table>
    </div>   
        <div id="listdata" class="container">
          
        </div>
    </div>
</body>
</html>
<script type="text/javascript">
$(document).ready(function() {
    jQuery.validator.addMethod("greaterThan", 
    function(value, element, params) {

        if (!/Invalid|NaN/.test(new Date(value))) {
            return new Date(value) > new Date($(params).val());
        }

        return isNaN(value) && isNaN($(params).val()) 
            || (Number(value) > Number($(params).val())); 
    },'Must be greater than {0}.');
    $('.enddate,.startdate').datepicker();  
    $('#example').DataTable();
    $('#InsertEvent').validate({ // initialize the plugin
        rules: {
            title: {
                required: true,             
            },            
            Repeat: {
                required: true,             
            },            
            startdate: {
                required: true,             
            },            
            enddate: {
                required: true, 
                greaterThan: "#StartDate"            
            },              
        },
        messages: {        
            enddate: {
                greaterThan: "End Date must be greater then start date",            
            }
        }
    });          
});
$(document).on('click','#insertData',function(e){
    e.preventDefault();
    var IsValid = $('#InsertEvent').valid();
    if (IsValid) {
        $.ajax({
            type: "POST",
            url: "index.php",    
            data: $("form").serialize(),
            success: function(data){
                window.location.reload();                      
            }
        });
    }
});
$(document).on('click','#eventview',function(e){
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "index.php",    
        data: "id="+ $(this).attr('view-id'),
        success: function(html){                
            $('#listdata').html(html);            
        }
    });
});
</script>
